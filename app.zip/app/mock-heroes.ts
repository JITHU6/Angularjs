import { Hero } from './hero';

export const HEREOS: Hero[]=[
    {id:1,name:'Nakul'},
    {id:2,name:'Alif'},
    {id:3,name:'Haritha'},
    {id:4,name:'Stibin'},
    {id:5,name:'Deepak'},

]