import {Recipe} from './recipe.model'
import { EventEmitter, Injectable } from '@angular/core';
import { Incredient } from '../shared/incredient.model';
import { ShopingListService } from '../shopping-list/shopping-list.service';
@Injectable()
export class RecipeService{
    recipeSelected = new EventEmitter<Recipe>();
    private recipes:Recipe[] = [
        new Recipe('abc',
        'def',
        'https://storage.needpix.com/rsynced_images/fish-1101436_1280.jpg',
        [
            new Incredient('Meat','1'),
            new Incredient('aalu','11'),
        ]),
        new Recipe('abc',
        'def',
        'https://storage.needpix.com/rsynced_images/fish-1101436_1280.jpg',
        [
            new Incredient('milk','1'),
            new Incredient('tomato','1'),
        ]),
        new Recipe('abc',
        'def',
        'https://storage.needpix.com/rsynced_images/fish-1101436_1280.jpg',
        [
            new Incredient('beef','1'),
            new Incredient('coconut','1'),
        ])
      ];
    constructor(private slService:ShopingListService){
        
    }
    getRecipe(){
        return this.recipes.slice();
    }
    addIngredientsToShoppingList(ingredients:Incredient[]){
        this.slService.addIncredients(ingredients);
    }

}