import { Injectable } from '@angular/core';
import { Hero } from './hero';
import { HEREOS } from './mock-heroes';
import { Observable, of} from 'rxjs';
import { MessageService } from './message.service';
@Injectable({
  providedIn: 'root'
})
export class HeroService {
getHeroes(): Observable<Hero[]>{
  this.MessageService.add('HeroService:Fetch Heroes');
  return of(HEREOS);
}
constructor(private MessageService:MessageService) { }
  
}
