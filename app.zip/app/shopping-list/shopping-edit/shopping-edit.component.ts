import { Component, OnInit, ElementRef, ViewChild, EventEmitter, Output } from '@angular/core';
import { Incredient } from 'src/app/shared/incredient.model';
import { ShopingListService } from '../shopping-list.service';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit {
  @ViewChild('nameinput',{static: false}) nameInputRef: ElementRef;
  @ViewChild('amountinput',{static: false}) amountInputRef: ElementRef;
  constructor(private slService:ShopingListService) { }

  ngOnInit() {
  }
  onAddItem(){
    console.log("aaaaaaaaaa")
    const increName = this.nameInputRef.nativeElement.value;
    const increAmount= this.amountInputRef.nativeElement.value;
    const newIncredient = new Incredient(increName, increAmount)

    this.slService.addIncredient(newIncredient);
  }
}
