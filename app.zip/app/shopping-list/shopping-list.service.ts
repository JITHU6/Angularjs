import { Incredient } from '../shared/incredient.model'
import { EventEmitter } from '@angular/core';
export class ShopingListService{
    incredientChanged=new EventEmitter<Incredient[]>();
    private incredients:Incredient[] = [
        new Incredient('apples','5'),
        new Incredient('orange','15'),
      ];
    getIngredient(){
        return this.incredients.slice();
    }
    addIncredient(incre:Incredient){
        this.incredients.push(incre);
        this.incredientChanged.emit(this.incredients.slice());
      }
    addIncredients(incre:Incredient[]){
        this.incredients.push(...incre);
        this.incredientChanged.emit(this.incredients.slice());
    }
}