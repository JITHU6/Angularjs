export class Incredient{
    constructor(public name:string,public amount:string){
    }
}