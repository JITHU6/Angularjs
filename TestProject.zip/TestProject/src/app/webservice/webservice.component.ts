import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TestService } from '../test.service';
import { student } from '../student';

@Component({
  selector: 'app-webservice',
  templateUrl: './webservice.component.html',
  styleUrls: ['./webservice.component.css']
})
export class WebserviceComponent implements OnInit {
  //declaring student class
  student = new student();
  error: any;
  success: any;
  //creating instance of serviceclass
  constructor(private obj: TestService) {

  }

  ngOnInit() {
  }
  registration(f: NgForm) {
    //calling store method of service method and passing data to student class.
    this.obj.store(this.student).subscribe(
      //assign data or error message.
      data => {
        this.success = "registration ok";
        f.reset();
      }, (err) => { this.error = err; }
    );

  }

}
