import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-helloworld',
  templateUrl: './helloworld.component.html',
  styleUrls: ['./helloworld.component.css']
})
export class HelloworldComponent implements OnInit {
  message: string = "welcome jithu";
  msg: string = new Date().toDateString();
  user: any;
  collapse: boolean = true;
  constructor() {
    this.user = {
      name: "Jithu",
      job: "Developer",
      address: ["1234", "kottayam"],
      pin: "1234567",
      phone: ["123", "3456", "56778", "2335465658"]
    };

  }
  toggle() {
    this.collapse =!this.collapse;
  }

  ngOnInit() {
  }

}
