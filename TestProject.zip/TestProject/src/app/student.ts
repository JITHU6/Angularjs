export class student {
    name: string;
    email: string;
    phone: string;
    password:string;
    id?: number;

    constructor() {

    }
}